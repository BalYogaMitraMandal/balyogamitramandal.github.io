<?php

$todayis = date("l, F j, Y, g:i a") ;

$name=$_POST["nameTextBox"];
$subject = "A message left on BYMM website, by: ".$name;

$notes = stripcslashes($_POST["questionTextArea"]);

$message = " $todayis [EST] \n

Message:
$notes \n

";

$from = "From: ".$_POST["emailTextBox"];

mail("bymm.jamshedpur@gmail.com", $subject, $message, $from); 

echo '<script type="text/javascript">
location="emailSent.html";
</script>';   

?>
